// SigPlusFontGenPpg.cpp : Implementation of the CSigPlusFontGenPropPage property page class.

#include "stdafx.h"
#include "SigPlusFontGen.h"
#include "SigPlusFontGenPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CSigPlusFontGenPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CSigPlusFontGenPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CSigPlusFontGenPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CSigPlusFontGenPropPage, "SIGPLUSFONTGEN.SigPlusFontGenPropPage.1",
	0xbe5978f2, 0x14a8, 0x45ee, 0xb4, 0xfe, 0x9c, 0x18, 0x3d, 0xc, 0xe0, 0x3b)


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenPropPage::CSigPlusFontGenPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CSigPlusFontGenPropPage

BOOL CSigPlusFontGenPropPage::CSigPlusFontGenPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_SIGPLUSFONTGEN_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenPropPage::CSigPlusFontGenPropPage - Constructor

CSigPlusFontGenPropPage::CSigPlusFontGenPropPage() :
	COlePropertyPage(IDD, IDS_SIGPLUSFONTGEN_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CSigPlusFontGenPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenPropPage::DoDataExchange - Moves data between page and properties

void CSigPlusFontGenPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CSigPlusFontGenPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenPropPage message handlers
