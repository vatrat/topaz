// SigPlusFontGenCtl.cpp : Implementation of the CSigPlusFontGenCtrl ActiveX Control class.

#include "stdafx.h"
#include "SigPlusFontGen.h"
#include "SigPlusFontGenCtl.h"
#include "SigPlusFontGenPpg.h"

#include <sys/stat.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif





IMPLEMENT_DYNCREATE(CSigPlusFontGenCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CSigPlusFontGenCtrl, COleControl)
	//{{AFX_MSG_MAP(CSigPlusFontGenCtrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CSigPlusFontGenCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CSigPlusFontGenCtrl)
	DISP_FUNCTION(CSigPlusFontGenCtrl, "WriteFont", WriteFont, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION(CSigPlusFontGenCtrl, "SetFont", SetFont, VT_EMPTY, VTS_I4 VTS_I4 VTS_I4 VTS_I2 VTS_I2 VTS_I2 VTS_BSTR)
	DISP_FUNCTION(CSigPlusFontGenCtrl, "MakeTopazImage", MakeTopazImage, VT_BOOL, VTS_HANDLE VTS_BSTR)
	DISP_FUNCTION(CSigPlusFontGenCtrl, "MakeTopazImageFromFile", MakeTopazImageFromFile, VT_BOOL, VTS_BSTR VTS_BSTR)
	DISP_FUNCTION(CSigPlusFontGenCtrl, "WriteFontEmbedded", WriteFontEmbedded, VT_BOOL, VTS_BSTR VTS_BSTR)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CSigPlusFontGenCtrl, COleControl)
	//{{AFX_EVENT_MAP(CSigPlusFontGenCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CSigPlusFontGenCtrl, 1)
	PROPPAGEID(CSigPlusFontGenPropPage::guid)
END_PROPPAGEIDS(CSigPlusFontGenCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CSigPlusFontGenCtrl, "SIGPLUSFONTGEN.SigPlusFontGenCtrl.1",
	0xca4bba6c, 0x789f, 0x453f, 0xb4, 0x79, 0x72, 0xc8, 0x30, 0xe3, 0x77, 0x86)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CSigPlusFontGenCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DSigPlusFontGen =
		{ 0x44f5b619, 0x6879, 0x4dac, { 0x98, 0xa, 0x8f, 0x1, 0xe5, 0x64, 0x99, 0x72 } };
const IID BASED_CODE IID_DSigPlusFontGenEvents =
		{ 0xa2986fb5, 0x6875, 0x42b1, { 0x81, 0x76, 0x11, 0xc2, 0x79, 0xca, 0x34, 0xe7 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwSigPlusFontGenOleMisc =
	OLEMISC_INVISIBLEATRUNTIME |
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CSigPlusFontGenCtrl, IDS_SIGPLUSFONTGEN, _dwSigPlusFontGenOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl::CSigPlusFontGenCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CSigPlusFontGenCtrl

BOOL CSigPlusFontGenCtrl::CSigPlusFontGenCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_SIGPLUSFONTGEN,
			IDB_SIGPLUSFONTGEN,
			afxRegApartmentThreading,
			_dwSigPlusFontGenOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl::CSigPlusFontGenCtrl - Constructor

CSigPlusFontGenCtrl::CSigPlusFontGenCtrl()
{
	InitializeIIDs(&IID_DSigPlusFontGen, &IID_DSigPlusFontGenEvents);

	// TODO: Initialize your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl::~CSigPlusFontGenCtrl - Destructor

CSigPlusFontGenCtrl::~CSigPlusFontGenCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl::OnDraw - Drawing function

void CSigPlusFontGenCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->Ellipse(rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl::DoPropExchange - Persistence support

void CSigPlusFontGenCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl::OnResetState - Reset control to default state

void CSigPlusFontGenCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl message handlers

void 
CSigPlusFontGenCtrl::SetFont(long Height, long Width, long Weight, short Italic, short Underline, short PitchAndFamily, LPCTSTR FaceName) 

{
FontHeight = Height;
FontWidth = Width;
FontWeight = Weight;
FontItalic = Italic;
FontUnderline = Underline;
FontPitchAndFamily = PitchAndFamily;
strncpy( FontFaceName, FaceName, sizeof( FontFaceName ) );
}



static unsigned char ByteMask[] =
	{
	0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 
	} ;



void 
CSigPlusFontGenCtrl::WriteFont(LPCTSTR FontFileName) 

{

CDC							DrawDc;
CBitmap						BitMap;
CBitmap*						OldBM;
LOGFONT						logFont;
CFont							font;
CFont*						OldFont = NULL;
long							i;
long							j;
CBrush*						OldBrush;
COLORREF						BackColor = RGB( 0xFF, 0xFF, 0xFF );
CBrush						BackBrush( BackColor );
CSize							WindowSize;
COLORREF						PixVal;
short							NewXSize;
short							NewYSize;
int							XSize = 256;
int							YSize = 256;
short							CharCount;
short							Ch;
unsigned char				ByteBuff;
unsigned char				ChBuffer[ 10 ];
FILE*							FontFile;

if ( DrawDc.CreateCompatibleDC( NULL ) == 0 )
	{
	return;
	}

int NumPlanes = DrawDc.GetDeviceCaps( PLANES );
int NumBits = DrawDc.GetDeviceCaps( BITSPIXEL );

if ( BitMap.CreateBitmap( XSize, YSize, NumPlanes, NumBits, NULL ) == 0 )
	{
	return;
	}
OldBM = DrawDc.SelectObject( &BitMap );
OldBrush = DrawDc.SelectObject( &BackBrush );
CRect DRect = CRect( 0, 0, XSize, YSize );


memset(&logFont, 0, sizeof(LOGFONT));
logFont.lfHeight = FontHeight;
logFont.lfWidth = FontWidth;
logFont.lfWeight = FontWeight;
logFont.lfItalic = (unsigned char)FontItalic;
logFont.lfUnderline = (unsigned char)FontUnderline;
logFont.lfPitchAndFamily = (unsigned char)FontPitchAndFamily;
strcpy( logFont.lfFaceName, FontFaceName );

if (font.CreateFontIndirect(&logFont))
	{
	OldFont = DrawDc.SelectObject(&font);
   }


DrawDc.SetTextAlign(TA_LEFT | TA_TOP);

FontFile = fopen( FontFileName, "wb" );
if ( FontFile == NULL )
	{
	return;
	}

CharCount = 255;

fwrite( &CharCount, sizeof( CharCount ), 1, FontFile );

for( Ch = 1; Ch < ( CharCount + 1 ); Ch++ )
	{
	DrawDc.FillRect( DRect, &BackBrush);
	ChBuffer[ 0 ] = (unsigned char)Ch;
	ChBuffer[ 1 ] = '\0';
	DrawDc.TextOut( 0, 0, ChBuffer );
	WindowSize = DrawDc.GetTextExtent( (const char*)ChBuffer, 1 );

	NewXSize = (short)WindowSize.cx;
	NewYSize = (short)WindowSize.cy;

	fwrite( &Ch, 1, 1, FontFile );
	fwrite( &NewXSize, sizeof( NewXSize ), 1, FontFile );
	fwrite( &NewYSize, sizeof( NewYSize ), 1, FontFile );

	for( i = 0; i < NewYSize; i++ )
		{
		for( j = 0; j < NewXSize; j++ )
			{
			if ( ( j % 8 ) == 0 )
				{
				if ( j != 0 )
					{
					fwrite( &ByteBuff, 1, 1, FontFile );
					}
				ByteBuff = 0;
				}
			PixVal = DrawDc.GetPixel( j, i );
			if (  PixVal != 0x00FFFFFF )
				{
				ByteBuff |= ByteMask[ j % 8 ];
				}
			}
//		if ( ( ( j % 8 ) != 1 ) && ( j != 0 ) )
//			{
			fwrite( &ByteBuff, 1, 1, FontFile );
//			}
		}	
	}

fclose( FontFile );

DrawDc.SelectObject( OldFont );
DrawDc.SelectObject( OldBM );
DrawDc.SelectObject( OldBrush );

font.DeleteObject();
BitMap.DeleteObject();
BackBrush.DeleteObject();

}


BOOL 
CSigPlusFontGenCtrl::MakeTopazImage(OLE_HANDLE BitMapHandle, LPCTSTR ImageFileName) 

{
CBitmap						DummyBmp;
CBitmap*						TmpBmp;
CDC							TmpDc;
BITMAP						BmpData;
CBitmap*						OldBM;
int							i;
int							j;
COLORREF						PixVal;
FILE*							ImageFile;
short							XSize;
short							YSize;
unsigned char				HighValue = 0xFF;
unsigned char				LowValue = 0x00;


TmpBmp = DummyBmp.FromHandle( (HBITMAP)BitMapHandle );
if ( TmpBmp == NULL )
	{
	return FALSE;
	}
TmpBmp->GetBitmap( &BmpData );

if ( TmpDc.CreateCompatibleDC( NULL ) == 0 )
	{
	return FALSE;
	}	
OldBM = TmpDc.SelectObject( TmpBmp );

XSize = (short)BmpData.bmWidth;
YSize = (short)BmpData.bmHeight;

ImageFile = fopen( ImageFileName, "wb" );
if ( ImageFile == NULL )
	{
	return FALSE;
	}

fwrite( &XSize, sizeof( XSize ), 1, ImageFile );
fwrite( &YSize, sizeof( YSize ), 1, ImageFile );

for( i = 0; i < XSize; i++ )
	{
	for( j = 0; j < YSize; j++ )
		{
		PixVal = TmpDc.GetPixel( i, j );
		if (  PixVal != 0x00FFFFFF )
			{
			fwrite( &HighValue, 1, 1, ImageFile );
			}
		else
			{
			fwrite( &LowValue, 1, 1, ImageFile );
			}
		}
	}

fclose( ImageFile );
OldBM = TmpDc.SelectObject( OldBM );

return TRUE;
}







BOOL 
CSigPlusFontGenCtrl::MakeTopazImageFromFile(LPCTSTR SourceFileName, LPCTSTR ImageFileName) 

{

HANDLE						Bmp;
CBitmap						DummyBmp;
CBitmap*						TmpBmp;
CDC							TmpDc;
BITMAP						BmpData;
CBitmap*						OldBM;
int							i;
int							j;
COLORREF						PixVal;
FILE*							ImageFile;
short							XSize;
short							YSize;
unsigned char				HighValue = 0xFF;
unsigned char				LowValue = 0x00;

Bmp = LoadImage( NULL, SourceFileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE );
if ( Bmp == NULL )
	{
	return FALSE;
	}
TmpBmp = DummyBmp.FromHandle( (HBITMAP)Bmp );
if ( TmpBmp == NULL )
	{
	return FALSE;
	}
TmpBmp->GetBitmap( &BmpData );

if ( TmpDc.CreateCompatibleDC( NULL ) == 0 )
	{
	return FALSE;
	}	
OldBM = TmpDc.SelectObject( TmpBmp );

XSize = (short)BmpData.bmWidth;
YSize = (short)BmpData.bmHeight;

ImageFile = fopen( ImageFileName, "wb" );
if ( ImageFile == NULL )
	{
	return FALSE;
	}

fwrite( &XSize, sizeof( XSize ), 1, ImageFile );
fwrite( &YSize, sizeof( YSize ), 1, ImageFile );

for( j = 0; j < YSize; j++ )
	{
	for( i = 0; i < XSize; i++ )
		{
		PixVal = TmpDc.GetPixel( i, j );
		if (  PixVal != 0x00FFFFFF )
			{
			fwrite( &HighValue, 1, 1, ImageFile );
			}
		else
			{
			fwrite( &LowValue, 1, 1, ImageFile );
			}
		}
	}

fclose( ImageFile );
OldBM = TmpDc.SelectObject( OldBM );

return TRUE;
}


const char*		TempFileName = "SigFont.tmp";

BOOL 
CSigPlusFontGenCtrl::WriteFontEmbedded(LPCTSTR FileName, LPCTSTR FontName) 
	
{
FILE*				TempFile;
FILE*				DestFile;
int				i;
int				Ch;
int				FileSize;
char				FullFileName[ 512 ];


WriteFont( TempFileName );

TempFile = fopen( TempFileName, "rb" );
if ( TempFile == NULL )
	{
	return FALSE;
	}
for( FileSize = 0; ; FileSize++ )
	{
	Ch = fgetc( TempFile );
	if ( feof( TempFile ) )
		{
		break;
		}
	}

fseek( TempFile, 0, SEEK_SET );

sprintf( FullFileName, "%s.cpp", FileName );

DestFile = fopen( FullFileName, "w" );
if ( DestFile == NULL )
	{
	fclose( TempFile );
	return FALSE;
	}

fprintf( DestFile, "\n\n\nunsigned char\t%s[ %d ] = \n\t{\n\t", FontName, FileSize );
for( i = 0; i < FileSize; i++ )
	{
	if ( ( i != 0 ) && ( ( i % 16 ) == 0 ) )
		{
		fprintf( DestFile, "\n\t" );
		}
	Ch = fgetc( TempFile );
	fprintf( DestFile, "0x%02x", Ch );
	if ( i != ( FileSize - 1 ) )
		{
		fprintf( DestFile, ", " );
		}
	else
		{
		fprintf( DestFile, "\n\t};\n\n" );
		}
	}
fclose( DestFile );
fclose( TempFile );
DeleteFile( TempFileName );

sprintf( FullFileName, "%s.h", FileName );
DestFile = fopen( FullFileName, "w" );
if ( DestFile == NULL )
	{
	return FALSE;
	}

fprintf( DestFile, "\n\nextern unsigned char	%s[];\n\n", FontName );
fprintf( DestFile, "#define\t%s_Size\t%d\n\n", FontName, FileSize );

fclose( DestFile );

return TRUE;
}



