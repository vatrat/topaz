#if !defined(AFX_SIGPLUSFONTGENCTL_H__12EC48E5_5FD9_47E5_8808_27F5AB4E0C00__INCLUDED_)
#define AFX_SIGPLUSFONTGENCTL_H__12EC48E5_5FD9_47E5_8808_27F5AB4E0C00__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// SigPlusFontGenCtl.h : Declaration of the CSigPlusFontGenCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenCtrl : See SigPlusFontGenCtl.cpp for implementation.

class CSigPlusFontGenCtrl : public COleControl
{
	DECLARE_DYNCREATE(CSigPlusFontGenCtrl)

// Constructor
public:
	CSigPlusFontGenCtrl();

	long					FontHeight;
	long					FontWidth;
	long					FontWeight;
	short					FontItalic;
	short					FontUnderline;
	short					FontPitchAndFamily;
	char					FontFaceName[ LF_FACESIZE ];

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSigPlusFontGenCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CSigPlusFontGenCtrl();

	DECLARE_OLECREATE_EX(CSigPlusFontGenCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CSigPlusFontGenCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CSigPlusFontGenCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CSigPlusFontGenCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CSigPlusFontGenCtrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CSigPlusFontGenCtrl)
	afx_msg void WriteFont(LPCTSTR FontFileName);
	afx_msg void SetFont(long Height, long Width, long Weight, short Italic, short Underline, short PitchAndFamily, LPCTSTR FaceName);
	afx_msg BOOL MakeTopazImage(OLE_HANDLE BitMapHandle, LPCTSTR ImageFileName);
	afx_msg BOOL MakeTopazImageFromFile(LPCTSTR SourceFileName, LPCTSTR ImageFileName);
	afx_msg BOOL WriteFontEmbedded(LPCTSTR FileName, LPCTSTR FontName);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

// Event maps
	//{{AFX_EVENT(CSigPlusFontGenCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CSigPlusFontGenCtrl)
	dispidWriteFont = 1L,
	dispidSetFont = 2L,
	dispidMakeTopazImage = 3L,
	dispidMakeTopazImageFromFile = 4L,
	dispidWriteFontEmbedded = 5L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGPLUSFONTGENCTL_H__12EC48E5_5FD9_47E5_8808_27F5AB4E0C00__INCLUDED)
