

extern unsigned char	Test20Font[];

#define	Test20Font_Size	8957

