// SIgPlusFontGenTest.h : main header file for the SIGPLUSFONTGENTEST application
//

#if !defined(AFX_SIGPLUSFONTGENTEST_H__FB0BFF02_3214_4ABD_861D_491C7D660115__INCLUDED_)
#define AFX_SIGPLUSFONTGENTEST_H__FB0BFF02_3214_4ABD_861D_491C7D660115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSIgPlusFontGenTestApp:
// See SIgPlusFontGenTest.cpp for the implementation of this class
//

class CSIgPlusFontGenTestApp : public CWinApp
{
public:
	CSIgPlusFontGenTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSIgPlusFontGenTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSIgPlusFontGenTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGPLUSFONTGENTEST_H__FB0BFF02_3214_4ABD_861D_491C7D660115__INCLUDED_)
