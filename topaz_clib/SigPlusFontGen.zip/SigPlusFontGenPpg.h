#if !defined(AFX_SIGPLUSFONTGENPPG_H__AADF56CD_1CF3_49FC_AE2F_80C968D8EA70__INCLUDED_)
#define AFX_SIGPLUSFONTGENPPG_H__AADF56CD_1CF3_49FC_AE2F_80C968D8EA70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// SigPlusFontGenPpg.h : Declaration of the CSigPlusFontGenPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CSigPlusFontGenPropPage : See SigPlusFontGenPpg.cpp.cpp for implementation.

class CSigPlusFontGenPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CSigPlusFontGenPropPage)
	DECLARE_OLECREATE_EX(CSigPlusFontGenPropPage)

// Constructor
public:
	CSigPlusFontGenPropPage();

// Dialog Data
	//{{AFX_DATA(CSigPlusFontGenPropPage)
	enum { IDD = IDD_PROPPAGE_SIGPLUSFONTGEN };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CSigPlusFontGenPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGPLUSFONTGENPPG_H__AADF56CD_1CF3_49FC_AE2F_80C968D8EA70__INCLUDED)
